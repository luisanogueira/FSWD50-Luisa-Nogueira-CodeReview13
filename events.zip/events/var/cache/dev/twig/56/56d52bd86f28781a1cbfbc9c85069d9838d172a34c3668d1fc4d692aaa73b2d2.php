<?php

/* events/details.html.twig */
class __TwigTemplate_08875945bf08545581e17209fe380dbcb35d341f281e9db7cacbc61e3d918cc6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "events/details.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "events/details.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "events/details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "
    <div class=\"col-12\">
\t\t<h2 class=\"m-3 p-3 text-center\">";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "name", array()), "html", null, true);
        echo "</h2>
\t</div>
\t<div class=\"col-12\">
\t\t<img src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "image", array()), "html", null, true);
        echo "\" class=\"img-fluid\" style=\"height:400px\">
\t\t<ul class=\"list-group\">
\t\t\t   <li class=\"list-group-item\">Date: <strong> ";
        // line 10
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "date", array()), "F j, Y, g:i a"), "html", null, true);
        echo " </strong> </li>
               <li class=\"list-group-item\">Capacity: ";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "capacity", array()), "html", null, true);
        echo "</li>
               <li class=\"list-group-item\">Email: ";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "email", array()), "html", null, true);
        echo "</li>
               <li class=\"list-group-item\">Phone: ";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "phone", array()), "html", null, true);
        echo "</li>
               <li class=\"list-group-item\">Phone: ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "address", array()), "html", null, true);
        echo "</li>
               <li class=\"list-group-item\">Website: ";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "website", array()), "html", null, true);
        echo "</li>
               <li class=\"list-group-item\">Type: ";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "type", array()), "html", null, true);
        echo "</li>
               <li class=\"list-group-item\">Description: ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute(($context["events"] ?? $this->getContext($context, "events")), "description", array()), "html", null, true);
        echo "</li>
               
       </ul>
       <hr>
       <a class=\"btn btn-info m-3\" href=\"/\">Back to Events</a>
\t</div>
       
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "events/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 17,  88 => 16,  84 => 15,  80 => 14,  76 => 13,  72 => 12,  68 => 11,  64 => 10,  59 => 8,  53 => 5,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}

    <div class=\"col-12\">
\t\t<h2 class=\"m-3 p-3 text-center\">{{events.name}}</h2>
\t</div>
\t<div class=\"col-12\">
\t\t<img src=\"{{events.image}}\" class=\"img-fluid\" style=\"height:400px\">
\t\t<ul class=\"list-group\">
\t\t\t   <li class=\"list-group-item\">Date: <strong> {{events.date|date('F j, Y, g:i a')}} </strong> </li>
               <li class=\"list-group-item\">Capacity: {{events.capacity}}</li>
               <li class=\"list-group-item\">Email: {{events.email}}</li>
               <li class=\"list-group-item\">Phone: {{events.phone}}</li>
               <li class=\"list-group-item\">Phone: {{events.address}}</li>
               <li class=\"list-group-item\">Website: {{events.website}}</li>
               <li class=\"list-group-item\">Type: {{events.type}}</li>
               <li class=\"list-group-item\">Description: {{events.description}}</li>
               
       </ul>
       <hr>
       <a class=\"btn btn-info m-3\" href=\"/\">Back to Events</a>
\t</div>
       
{% endblock %}", "events/details.html.twig", "C:\\xampp\\htdocs\\events\\app\\Resources\\views\\events\\details.html.twig");
    }
}
