<?php

/* events/index.html.twig */
class __TwigTemplate_ef056337dc2b6bd49100d6909fe8bfb00a906d36f71d06ced1e788345cc9ed50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "events/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "events/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "events/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "\t<div class=\"col-12\">
\t\t<h2 class=\"m-3 p-3 text-center\">All Events</h2>
\t</div>
\t
\t";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["events"] ?? $this->getContext($context, "events")));
        foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
            // line 8
            echo "\t<div class=\"col-lg-4 col-md-4 col-sm-12 pb-3\">
\t\t<div class=\"card\" style=\"width: 18rem;\">
\t\t\t  <img class=\"card-img-top\" style=\"height: 200px\" src=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "image", array()), "html", null, true);
            echo "\" alt=\"Card image cap\">
\t\t\t  <div class=\"card-body\">
\t\t\t    <h5 class=\"card-title\">";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "name", array()), "html", null, true);
            echo "</h5>
\t\t\t  </div>
\t\t\t  <ul class=\"list-group list-group-flush\">
\t\t\t    <li class=\"list-group-item\">Date: ";
            // line 15
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["event"], "date", array()), "F j, Y, g:i a"), "html", null, true);
            echo "</li>
\t\t\t    <li class=\"list-group-item\"><a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "website", array()), "html", null, true);
            echo "\" target=\"_blank\">Website</a></li>
\t\t\t    <li class=\"list-group-item\">Type: ";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "type", array()), "html", null, true);
            echo "</li>
\t\t\t  </ul>
\t\t\t  <div class=\"card-body\">
\t\t\t    <a href=\"/events/details/";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-info\">View</a>
\t\t\t    <a href=\"/events/edit/";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-success\">Edit</a>
\t\t\t    <a href=\"/events/delete/";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-danger\">Delete</a>
\t\t\t  </div>
\t\t</div>
\t</div>
\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "\t\t\t     
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "events/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 27,  96 => 22,  92 => 21,  88 => 20,  82 => 17,  78 => 16,  74 => 15,  68 => 12,  63 => 10,  59 => 8,  55 => 7,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}
\t<div class=\"col-12\">
\t\t<h2 class=\"m-3 p-3 text-center\">All Events</h2>
\t</div>
\t
\t{% for event in events %}
\t<div class=\"col-lg-4 col-md-4 col-sm-12 pb-3\">
\t\t<div class=\"card\" style=\"width: 18rem;\">
\t\t\t  <img class=\"card-img-top\" style=\"height: 200px\" src=\"{{event.image}}\" alt=\"Card image cap\">
\t\t\t  <div class=\"card-body\">
\t\t\t    <h5 class=\"card-title\">{{event.name}}</h5>
\t\t\t  </div>
\t\t\t  <ul class=\"list-group list-group-flush\">
\t\t\t    <li class=\"list-group-item\">Date: {{event.date|date('F j, Y, g:i a')}}</li>
\t\t\t    <li class=\"list-group-item\"><a href=\"{{event.website}}\" target=\"_blank\">Website</a></li>
\t\t\t    <li class=\"list-group-item\">Type: {{event.type}}</li>
\t\t\t  </ul>
\t\t\t  <div class=\"card-body\">
\t\t\t    <a href=\"/events/details/{{event.id}}\" class=\"btn btn-info\">View</a>
\t\t\t    <a href=\"/events/edit/{{event.id}}\" class=\"btn btn-success\">Edit</a>
\t\t\t    <a href=\"/events/delete/{{event.id}}\" class=\"btn btn-danger\">Delete</a>
\t\t\t  </div>
\t\t</div>
\t</div>
\t{% endfor %}
\t\t\t     
{% endblock %}", "events/index.html.twig", "C:\\xampp\\htdocs\\events\\app\\Resources\\views\\events\\index.html.twig");
    }
}
