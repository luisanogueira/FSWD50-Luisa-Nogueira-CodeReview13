-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 30-Nov-2018 às 20:40
-- Versão do servidor: 10.1.36-MariaDB
-- versão do PHP: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `events`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `capacity` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `events`
--

INSERT INTO `events` (`id`, `name`, `date`, `description`, `image`, `capacity`, `email`, `phone`, `address`, `website`, `type`) VALUES
(1, 'PAUL McCARTNEY', '2018-12-05 20:00:00', 'Paul McCartney, ex Beatles singer, will have a concert', 'https://cdn.viagogo.net/img/cat/10204/4/37.jpg', 16152, 'service@stadthalle.com', 98100200, 'Wiener Stadthalle - Roland-Rainer-Platz 1, Wien\r\n', 'https://www.stadthalle.com/en/schauen/events/699/PAUL-McCARTNEY', 'concert'),
(2, 'Christmas World', '2018-12-01 10:00:00', 'The market is located at the entrance of City Hall Square and offers Christmas gifts, Christmas tree decorations, handicrafts, culinary treats, confectionery and warming drinks. You can also ice skate on the 3000 m2 rink.', 'https://i2.wp.com/mynapoleoncomplex.com/wp-content/uploads/2015/01/Vienna-Christmas-Markets-02.jpg', 100000, 'info@wien.info', 43124555, 'Rathausplatz, 1010 Vienna', 'http://www.weihnachtsdorf.at/', 'market'),
(3, 'Der Opernball', '2018-12-11 19:00:00', 'Operetta by Richard Heuberger. A married provincial couple go to visit friends in the capital. The men are in the mood for adventure and the women put their fidelity to the test.', 'http://static3.fr.de/storage/image/2/6/7/3/733762_608x342_1oG23x_0v9AhI.jpg', 1261, 'info@wien.info', 514443670, 'Währinger Straße 78  1090 Wien - Volksoper', 'www.volksoper.at', 'opera'),
(4, 'Funkroom', '2018-12-07 22:00:00', 'Party at Fluc. This nightclub host parties and concerts without entrance fees upstairs and with moderate admission for club nights and concerts downstairs.', 'http://beatmakersessions.eu/wp-content/uploads/2012/11/featured-image2-710x450.jpg', 200, 'booking@fluc.at', 0, 'Praterstern 5, 1020 Wien', 'www.fluc.at', 'nightlife'),
(6, 'New Year\'s Concert', '2019-01-01 11:15:00', 'The New Year\'s Concert by the Vienna Philharmonic combines the best of the best: The cheerfully lively, but also somewhat reflective program of music with compositions by the Strauss dynasty and its contemporaries, ensures a good start to the still young ', 'https://az694788.vo.msecnd.net/lightbox/Images/NJK/NJK14/njk14_TRY_0497.jpg', 0, 'tickets@musikverein.at', 15058190, 'Musikvereinsplatz 1, 1010 Wien', 'www.wienerphilharmoniker.at', 'concert'),
(7, 'Lenny Kravitz', '2019-12-09 19:30:00', 'Lenny Kravitz is a famous north american singer whose style includes rock, soul and reggae.', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTsejjy9pDA_F7OS9i6ZurZf8lbACxgg0LNRsKQBLVQirzapd5L', 16152, 'service@stadthalle.com', 7999979, 'Wiener Stadthalle - Halle D, Roland Rainer Platz 1, 1150 Wien', 'http://lennykravitz.com/', 'concert');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
