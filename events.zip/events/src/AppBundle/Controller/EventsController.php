<?php
namespace AppBundle\Controller;

use AppBundle\Entity\Events;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class EventsController extends Controller
{
   /**
    * @Route("/", name="events_list")
    */
   public function listAction(Request $request)
   {
   	   $events = $this->getDoctrine()->getRepository('AppBundle:Events')->findAll();

       return $this->render('events/index.html.twig', array('events' => $events));
   }

   /**
    * @Route("/events/create", name="events_create")
    */
   public function createAction(Request $request)
   {
   	   $events = new Events;

   	   $form = $this->createFormBuilder($events)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   	   ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

       ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
   		->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

   		->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

   		->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

   		->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

   		->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

   		->add('website', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

   		->add('type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

   		->add('save', SubmitType::class, array('label'=> 'Create Events', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
       	->getForm();
       	$form->handleRequest($request);

       	if($form->isSubmitted() && $form->isValid()){
           //fetching data
           $name = $form['name']->getData();
           $date = $form['date']->getData();
           $description = $form['description']->getData();
           $image = $form['image']->getData();
           $capacity = $form['capacity']->getData();
           $email = $form['email']->getData();
           $phone = $form['phone']->getData();
           $address = $form['address']->getData();
           $website = $form['website']->getData();
           $type = $form['type']->getData();
           

// Here we will get the current date
           $now = new\DateTime('now');


/* these functions we bring from our entities, every column have a set function and we put the value that we get from the form */
           $events->setName($name);
           $events->setDate($date);
           $events->setDescription($description);
           $events->setImage($image);
           $events->setCapacity($capacity);
           $events->setEmail($email);
           $events->setPhone($phone);
           $events->setAddress($address);
           $events->setWebsite($website);
           $events->setType($type);
           
           $em = $this->getDoctrine()->getManager();
           $em->persist($events);
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Added'
                   );
           return $this->redirectToRoute('events_list');
       }

       	return $this->render('events/create.html.twig', array('form' => $form->createView()));
   }
           /**
    * @Route("/events/details/{id}", name="events_details")
    */
   public function detailsAction($id)
   {
   	   $events = $this->getDoctrine()->getRepository('AppBundle:Events')->find($id);
       return $this->render('events/details.html.twig', array('events' => $events));
   }
  
           /**
    * @Route("/events/edit/{id}", name="events_edit")
    */
   public function editAction($id, Request $request)
   {
      $events = $this->getDoctrine()->getRepository('AppBundle:Events')->find($id);

      $events->setName($events->getName());
      $events->setDate($events->getDate());
      $events->setDescription($events->getDescription());
      $events->setImage($events->getImage());
      $events->setCapacity($events->getCapacity());
      $events->setEmail($events->getEmail());
      $events->setPhone($events->getPhone());
      $events->setAddress($events->getAddress());
      $events->setWebsite($events->getWebsite());
      $events->setType($events->getType());

      $form = $this->createFormBuilder($events)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
       ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

       ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
      ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

      ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

      ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

      ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

      ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

      ->add('website', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

      ->add('type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

      ->add('save', SubmitType::class, array('label'=> 'Update Events', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
        ->getForm();
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
           //fetching data
           $name = $form['name']->getData();
           $date = $form['date']->getData();
           $description = $form['description']->getData();
           $image = $form['image']->getData();
           $capacity = $form['capacity']->getData();
           $email = $form['email']->getData();
           $phone = $form['phone']->getData();
           $address = $form['address']->getData();
           $website = $form['website']->getData();
           $type = $form['type']->getData();
           

// Here we will get the current date
           $now = new\DateTime('now');

           $em = $this->getDoctrine()->getManager();
           $events = $em->getRepository('AppBundle:Events')->find($id);

           $events->setName($name);
           $events->setDate($date);
           $events->setDescription($description);
           $events->setImage($image);
           $events->setCapacity($capacity);
           $events->setEmail($email);
           $events->setPhone($phone);
           $events->setAddress($address);
           $events->setWebsite($website);
           $events->setType($type);
   
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Updated'
                   );
           return $this->redirectToRoute('events_list');
       }

      return $this->render('events/edit.html.twig', array('events' => $events, 'form' => $form->createView()));
   }

   /**
    * @Route("/events/delete/{id}", name="events_delete")
    */
   public function deleteAction($id) {
    $em = $this->getDoctrine()->getManager();
    $events = $em->getRepository('AppBundle:Events')->find($id);
    $em->remove($events);
    $em->flush();
    $this->addFlash(
      'notice',
      'Event Removed'
    );
    return $this->redirectToRoute('events_list');
   }
}